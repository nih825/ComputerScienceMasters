#include "mg.h"
#include "nrutil.h"
#include <stdio.h>
int main(int argc, char **argv){
  int i,j;
  FILE *outfile;
  double **f;
  int n=4097;
  int ncycle=1;
  double dt=.05;
  double alpha=.01;
  double c= alpha*dt;
  f = dmatrix(1,n,1,n);
  f[1023][1023]=1.0;
  //  for (i=2;i<n;++i)
  //  for (j=2;j<n;++j)
  //    f[i][j] = 2.0;
  mglin(f,n,ncycle, c);
  /*  outfile = fopen("soln.dat", "w");*/
  /*  fwrite(&f[1][1],sizeof(double),n*n,outfile);*/
  /*  fclose(outfile);*/
}
