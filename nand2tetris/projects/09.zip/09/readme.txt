For this project run the folder labeled trivia in the emulator.  This program will build a robotic human body and add a new body part every time you press a key followed by enter.  Let me know if you have any questions.  Ignore the circle destruction folder that was another jack program I was working on for fun but does not work right now.

Nihar Bhupalam