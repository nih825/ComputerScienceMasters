import glob

print glob.glob("/*.jack")