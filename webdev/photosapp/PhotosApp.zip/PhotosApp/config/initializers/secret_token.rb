# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PhotosApp::Application.config.secret_token = '1714329b8a87bc18cd7f906fe18f0112237ef0f3d4d09b0222ff1e6ea670098ff70dc1bd756f6ad8bbd3b713a411db83ecfcd0a3d6c1587d5d440d622b47b161'
