class Photo < ActiveRecord::Base
  attr_accessible :title, :url
end
