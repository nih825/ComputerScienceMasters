//
//  ftcs.h
//  heatequationsolver
//
//  Created by Rukmaiah Bhupalam on 2/3/13.
//  Copyright (c) 2013 Nihar Bhupalam. All rights reserved.
//

#ifndef __heatequationsolver__ftcs__
#define __heatequationsolver__ftcs__

#include <iostream>

#endif /* defined(__heatequationsolver__ftcs__) */
